ct_$('html').ultimateGDPR({
    popup_style: {
        position: 'bottom-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance betwen popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        button_size: 'normal', // normal, large
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
        gear_icon_position: 'bottom-left', // top-left, top-center, top-right, center-left, center-right, bottom-left, bottom-center, bottom-right
        gear_icon_color: '#6a8ee7', //color in hex
    },
    popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        gear_display: true, // true, false when true displays icon with cookie settings
        popup_title: 'Cookies', // title for popup
        popup_text: 'Cookie-k Ahhoz, hogy az oldal megfelelően működjön, néha kis fájlokat helyezzünk el cookie-ként az eszközön. A legtöbb nagy weboldal is ezt teszi.', // text for popup
        accept_button_text: 'Elfogad', // string, text for accept button
        read_button_text: 'Olvass tovább', // string, text for read more button
        read_more_link: '', // string, link to the Read More page
        advenced_button_text: 'Beállítások megváltoztatása', // string, text for advenced button
        grouped_popup: true, // true, false, when true cookies are grouped
        default_group: 'group_2', // string: name, select group that will be selected by default
        content_before_slider: '<h2>Adatvédelmi beállítások</h2><div class="ct-ultimate-gdpr-cookie-modal-desc"><p>Döntse el, hogy mely cookie-kat kívánja engedélyezni.</p><p>Bármikor módosíthatja ezeket a beállításokat. Ez azonban azt eredményezheti, hogy bizonyos funkciók már nem állnak rendelkezésre. A cookie-k törlésével kapcsolatos információkat a böngésző súgójában találja.</p> <span>További információ a használt cookie-król.</span></div><h3>A csúszkával engedélyezheti vagy letilthatja a különböző típusú cookie-kat:</h3>',
        // string: this content will be displayed before cookies slider, html tags alowed
        accepted_text: 'Ez a honlap lesz:',
        declined_text: "Ez a weboldal nem:",
        save_btn: 'Mentés és bezárás', // string, text for modal close btn
        prevent_cookies_on_document_write: false, // prevent cookies on document write when there is no agreement for cookies
        check_country: false,
        countries_prefixes: ['AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'GB'],
        cookies_expire_time: 30, // set number of days, you can use 0 for session only or 'unlimited'
        cookies_path: '/', // sets custom path use / for global, '/your_path' for custom path or 'current' for current path
        video_blocked: 'Ez a tartalom blokkolva van!',
        reset_link_selector: '.ct-uGdpr-reset',
        first_party_cookies_whitelist: [],
        third_party_cookies_whitelist: [],
        iframe_blocked: false,
        cookie_popup_close_color:'#fff',
        close_popup_text: '', // Close popup text (If empty, button X(close) will display. If not, it will display the text)
        cookies_groups: {
            group_1: {
                name: 'Alapvető', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-check', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Ne feledkezzen meg a cookie engedélybeállításáról', 'A munkamenet cookie-jainak engedélyezése', 'Gyűjtsd össze az információkat, amelyeket beírsz egy űrlapra, hírlevélre és egyéb formákra az összes oldalon', 'A bevásárlókosárba bevitt adatok nyomon követése', 'Hitelesítse be, hogy bejelentkezett a felhasználói fiókjába', 'Ne feledje a kiválasztott nyelvi verziót'], // array list of options
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_2: {
                name: 'funkcionalitás', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-cog', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Ne feledje a közösségi média beállításait', 'Jegyezd meg a kiválasztott régiót és országot',],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_3: {
                name: 'Analitika', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-chart-bar', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['Nyomon követheti a látogatott oldalakat és a kölcsönhatásokat', 'Tartsa nyomon az Ön helyét és régiót az IP-száma alapján', 'Tartsa nyomon az egyes oldalakra fordított időt', 'Növelje a statisztikai funkciók adatminőségét'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
            group_4: {
                name: 'Hirdető', // string: name
                enable: true, // true, false, you can disable this group by using false
                icon: 'fas fa-exchange-alt', // string icon class from font-awesome see -> http://fontawesome.io
                list: ['A harmadik felekkel történő személyre szabott hirdetésekre vonatkozó információk felhasználása', 'Lehetővé teszi a közösségi oldalakhoz való kapcsolódást', 'Az eszköz azonosítása', 'Gyűjtsön személyazonosításra alkalmas adatokat, például nevét és helyét'],
                blocked_url: [], // array list of url blocked scripts
                local_cookies_name: [], // array, list of local cookies names
            },
        },
    },
    age_popup_style: {
        position: 'top-panel', // bottom-left, bottom-right, bottom-panel, top-left, top-right, top-panel
        distance: '20px', // distance between popup and window border
        box_style: 'classic', // classic, modern
        box_shape: 'rounded', // rounded, squared
        background_color: '#fff584', // color in hex
        text_color: '#542d04', // color in hex
        button_shape: 'rounded', // squared, rounded
        button_color: '#e1e1e1', // color in hex
        box_skin: 'skin-dark-theme', // skin-default-theme, skin-dark-theme, skin-light-theme
    },
    age_popup_options: {
        parent_container: 'body', // append plugin html to this element selector
        always_show: false, // true, false, when true popup is displayed always even when consent is given
        popup_title: 'Age verification', // title for popup
        popup_text: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.', // text for popup
        age_limit: 13, // age limit to enter
        assets_path : 'assets', // absolute path to directory with assets
        disable_popup: false, // true/false, when true popup will be disabled and hidden on the website
    },
    forms: {
        prevent_forms_send: false, // true, false, when enabled forms get checkbox with info that need to be checked for form send
        prevent_forms_text: 'I consent to the storage of my data according to the Privacy Policy', // string: information for checkbox info
        prevent_forms_exclude: [], // array of selectors (classes, id), this forms will be excluded from prevent
    },
    configure_mode: {
        on: false,
        parametr: '?configure123456',
        dependencies: ['assets/css/ct-ultimate-gdpr.min.css', 'https://use.fontawesome.com/releases/v5.0.13/css/all.css'],
        debug: false, // bool: true false, debug mode on/off (showing all 3rd party cookies urls, blockes urls names of all local cookies and names of blocked local cookies )
    }
});